const textmanipulation = require("./textmanipulation");

module.exports = {
    textmanipulation: textmanipulation
};